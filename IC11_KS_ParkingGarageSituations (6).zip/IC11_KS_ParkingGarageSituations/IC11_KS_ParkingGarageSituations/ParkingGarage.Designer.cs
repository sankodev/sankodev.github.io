﻿namespace IC11_KS_ParkingGarageSituations
{
    partial class ParkingGarage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.hoursNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.parkingOptionsGroupBox = new System.Windows.Forms.GroupBox();
            this.monthlySpecialRadioButton = new System.Windows.Forms.RadioButton();
            this.nightlifeRadioButton = new System.Windows.Forms.RadioButton();
            this.nightRateRadioButton = new System.Windows.Forms.RadioButton();
            this.earlyBirdRadioButton = new System.Windows.Forms.RadioButton();
            this.calcButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.chargeLabel = new System.Windows.Forms.Label();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.chiParkingErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.hoursNumericUpDown)).BeginInit();
            this.parkingOptionsGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chiParkingErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // hoursNumericUpDown
            // 
            this.hoursNumericUpDown.Location = new System.Drawing.Point(215, 86);
            this.hoursNumericUpDown.Name = "hoursNumericUpDown";
            this.hoursNumericUpDown.Size = new System.Drawing.Size(120, 20);
            this.hoursNumericUpDown.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(174, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Hours:";
            // 
            // parkingOptionsGroupBox
            // 
            this.parkingOptionsGroupBox.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.parkingOptionsGroupBox.Controls.Add(this.monthlySpecialRadioButton);
            this.parkingOptionsGroupBox.Controls.Add(this.nightlifeRadioButton);
            this.parkingOptionsGroupBox.Controls.Add(this.nightRateRadioButton);
            this.parkingOptionsGroupBox.Controls.Add(this.earlyBirdRadioButton);
            this.parkingOptionsGroupBox.Location = new System.Drawing.Point(176, 134);
            this.parkingOptionsGroupBox.Name = "parkingOptionsGroupBox";
            this.parkingOptionsGroupBox.Size = new System.Drawing.Size(202, 170);
            this.parkingOptionsGroupBox.TabIndex = 2;
            this.parkingOptionsGroupBox.TabStop = false;
            this.parkingOptionsGroupBox.Text = "Parking Options:";
            // 
            // monthlySpecialRadioButton
            // 
            this.monthlySpecialRadioButton.AutoSize = true;
            this.monthlySpecialRadioButton.Location = new System.Drawing.Point(60, 129);
            this.monthlySpecialRadioButton.Name = "monthlySpecialRadioButton";
            this.monthlySpecialRadioButton.Size = new System.Drawing.Size(100, 17);
            this.monthlySpecialRadioButton.TabIndex = 3;
            this.monthlySpecialRadioButton.TabStop = true;
            this.monthlySpecialRadioButton.Text = "Monthly Special";
            this.monthlySpecialRadioButton.UseVisualStyleBackColor = true;
            // 
            // nightlifeRadioButton
            // 
            this.nightlifeRadioButton.AutoSize = true;
            this.nightlifeRadioButton.Location = new System.Drawing.Point(60, 97);
            this.nightlifeRadioButton.Name = "nightlifeRadioButton";
            this.nightlifeRadioButton.Size = new System.Drawing.Size(63, 17);
            this.nightlifeRadioButton.TabIndex = 2;
            this.nightlifeRadioButton.TabStop = true;
            this.nightlifeRadioButton.Text = "Nightlife";
            this.nightlifeRadioButton.UseVisualStyleBackColor = true;
            // 
            // nightRateRadioButton
            // 
            this.nightRateRadioButton.AutoSize = true;
            this.nightRateRadioButton.Location = new System.Drawing.Point(60, 65);
            this.nightRateRadioButton.Name = "nightRateRadioButton";
            this.nightRateRadioButton.Size = new System.Drawing.Size(76, 17);
            this.nightRateRadioButton.TabIndex = 1;
            this.nightRateRadioButton.TabStop = true;
            this.nightRateRadioButton.Text = "Night Rate";
            this.nightRateRadioButton.UseVisualStyleBackColor = true;
            // 
            // earlyBirdRadioButton
            // 
            this.earlyBirdRadioButton.AutoSize = true;
            this.earlyBirdRadioButton.Location = new System.Drawing.Point(60, 33);
            this.earlyBirdRadioButton.Name = "earlyBirdRadioButton";
            this.earlyBirdRadioButton.Size = new System.Drawing.Size(69, 17);
            this.earlyBirdRadioButton.TabIndex = 0;
            this.earlyBirdRadioButton.TabStop = true;
            this.earlyBirdRadioButton.Text = "Early Bird";
            this.earlyBirdRadioButton.UseVisualStyleBackColor = true;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(236, 319);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(85, 32);
            this.calcButton.TabIndex = 3;
            this.calcButton.Text = "&Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(174, 371);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Charge:";
            // 
            // chargeLabel
            // 
            this.chargeLabel.BackColor = System.Drawing.Color.White;
            this.chargeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.chargeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chargeLabel.Location = new System.Drawing.Point(176, 384);
            this.chargeLabel.Name = "chargeLabel";
            this.chargeLabel.Size = new System.Drawing.Size(192, 68);
            this.chargeLabel.TabIndex = 5;
            this.chargeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(177, 487);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 6;
            this.resetButton.Text = "&Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(293, 487);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.LimeGreen;
            this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label3.Location = new System.Drawing.Point(145, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 39);
            this.label3.TabIndex = 10;
            this.label3.Text = "Green";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(255, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 49);
            this.label4.TabIndex = 11;
            this.label4.Text = "Way";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(354, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(187, 66);
            this.label5.TabIndex = 12;
            this.label5.Text = "Chicago Illinois\r\nSouth Loop Areas";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.MediumBlue;
            this.label6.Location = new System.Drawing.Point(355, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 26);
            this.label6.TabIndex = 13;
            this.label6.Text = "House of Blues";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe Marker", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.LawnGreen;
            this.label7.Location = new System.Drawing.Point(357, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 15);
            this.label7.TabIndex = 14;
            this.label7.Text = "Self Service Parking";
            // 
            // chiParkingErrorProvider
            // 
            this.chiParkingErrorProvider.ContainerControl = this;
            this.chiParkingErrorProvider.Tag = "Input";
            // 
            // ParkingGarage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(539, 542);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.chargeLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.parkingOptionsGroupBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hoursNumericUpDown);
            this.Name = "ParkingGarage";
            this.Text = "Parking Garage";
            this.Load += new System.EventHandler(this.ParkingGarage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.hoursNumericUpDown)).EndInit();
            this.parkingOptionsGroupBox.ResumeLayout(false);
            this.parkingOptionsGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chiParkingErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown hoursNumericUpDown;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox parkingOptionsGroupBox;
        private System.Windows.Forms.RadioButton monthlySpecialRadioButton;
        private System.Windows.Forms.RadioButton nightlifeRadioButton;
        private System.Windows.Forms.RadioButton nightRateRadioButton;
        private System.Windows.Forms.RadioButton earlyBirdRadioButton;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label chargeLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ErrorProvider chiParkingErrorProvider;
    }
}

