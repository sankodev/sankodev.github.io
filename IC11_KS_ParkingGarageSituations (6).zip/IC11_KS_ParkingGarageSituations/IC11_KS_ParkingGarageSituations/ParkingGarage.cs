﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC11_KS_ParkingGarageSituations
{
    public partial class ParkingGarage : Form
    {

        enum ParkingRate { EarlyBird, NightRates, NightLife, MonthlySpecial };
        decimal parkingCharge = 0;
        ParkingRate typeOfRate;
         private decimal CalculateParkingCharge (double hoursParked, ParkingRate typeOfRate)
        {
            if (earlyBirdRadioButton.Checked == false && monthlySpecialRadioButton.Checked == false && nightlifeRadioButton.Checked == false && nightRateRadioButton.Checked == false)
            {
                chiParkingErrorProvider.SetError(parkingOptionsGroupBox, "Input Parking Selection.");
            }

            else
            {
                chiParkingErrorProvider.SetError(parkingOptionsGroupBox, "");
            }

            if (hoursNumericUpDown.Value == 0)
            {
                chiParkingErrorProvider.SetError(hoursNumericUpDown, "Input Parking Selection.");
            }

            else
            {
                chiParkingErrorProvider.SetError(hoursNumericUpDown, "");
            }
            //decimal parkingCharge = 0;
            switch (typeOfRate)
            {


                case ParkingRate.EarlyBird:
                    parkingCharge = 18m;
                    break;

                case ParkingRate.NightRates:
                    //parkingCharge = (decimal)hoursParked * 1.5m;
                    //parkingCharge = 
                    if (hoursParked <= 3)
                    {
                        parkingCharge = 16m;
                    }
                    else
                    {
                        parkingCharge = 21m;
                    }
                    break;

                case ParkingRate.NightLife:
                    parkingCharge = (decimal)hoursParked * 12.60m;
                    //if (parkingCharge > 21m)
                    //{
                    //    parkingCharge = 21m;
                    //}
                    break;

                case ParkingRate.MonthlySpecial:
                    //parkingCharge = (decimal)hoursParked * 1m;
                    //if (parkingCharge > 3m)
                    //{
                    //    parkingCharge = 3m;
                    //}
                    parkingCharge = 250m;
                    MessageBox.Show("Next 3 months paid for by this option.", "Monthly Special", MessageBoxButtons.OK, MessageBoxIcon.Warning);


                    break;

                default:
                    break;
                    
            }
            return (decimal)parkingCharge;
            //chargeLabel.Text = parkingCharge.ToString("C");
            //return CalculateParkingCharge;
        }

        public ParkingGarage()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ParkingGarage_Load(object sender, EventArgs e)
        {
            //parkingOptionsGroupBox.Enabled = false;
            //hoursNumericUpDown.Enabled = false;
            chargeLabel.Text = "$0.00";
            chargeLabel.ForeColor = Color.Red;
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            int hoursParked = (int)hoursNumericUpDown.Value;
            //ParkingRate typeOfRate;
            //validation

            if (earlyBirdRadioButton.Checked == false && monthlySpecialRadioButton.Checked ==  false && nightlifeRadioButton.Checked == false && nightRateRadioButton.Checked == false)
            {
                chiParkingErrorProvider.SetError(parkingOptionsGroupBox, "Input Parking Selection.");
                chargeLabel.Text = "$0.00";
                chargeLabel.ForeColor = Color.Red;
                return;
            }

            else
            {
                chiParkingErrorProvider.SetError(parkingOptionsGroupBox, "");
            }

            if (hoursNumericUpDown.Value == 0)
            {
                if (monthlySpecialRadioButton.Checked)
                {
                    chiParkingErrorProvider.SetError(hoursNumericUpDown, "");
                    typeOfRate = ParkingRate.MonthlySpecial;
                    chargeLabel.ForeColor = Color.LawnGreen;
                }
                else
                {
                    chiParkingErrorProvider.SetError(hoursNumericUpDown, "Input Parking Selection.");
                    //chargeLabel.Text = "$0.00";
                    //chargeLabel.ForeColor = Color.Red;
                }
                
                return;
            }

            else
            {
                chiParkingErrorProvider.SetError(hoursNumericUpDown, "");
            }
            //calling a function

            
            if (monthlySpecialRadioButton.Checked)
            {
                typeOfRate = ParkingRate.MonthlySpecial;
                chargeLabel.ForeColor = Color.LawnGreen;
                //chiParkingErrorProvider.SetError(hoursNumericUpDown, "");
            
            //else if statements
            
            }

            if (earlyBirdRadioButton.Checked)
            {
                typeOfRate = ParkingRate.EarlyBird;
                chargeLabel.ForeColor = Color.DarkOrange;
            }

            if (nightRateRadioButton.Checked)
            {
                typeOfRate = ParkingRate.NightRates;
                chargeLabel.ForeColor = Color.DarkSlateGray;
            }

            if (nightlifeRadioButton.Checked)
            {
                typeOfRate = ParkingRate.NightLife;
                chargeLabel.ForeColor = Color.BlueViolet;
            }

            parkingCharge = CalculateParkingCharge(hoursParked, typeOfRate);
            chargeLabel.Text = parkingCharge.ToString("C");
            

            //else
            //{
            //typeOfRate.____
            //chargeLabel.Text = ClaculateParkingCharge(hoursParked, typeOfRate).ToString("C");
            //}
        }

        private void byHourButton_Click(object sender, EventArgs e)
        {
            //hoursNumericUpDown.Enabled = true;
            //parkingOptionsGroupBox.Enabled = false;
        }

        private void specialsButton_Click(object sender, EventArgs e)
        {
            //parkingOptionsGroupBox.Enabled = true;
            //hoursNumericUpDown.Enabled = false;
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            hoursNumericUpDown.Value = 0;
            monthlySpecialRadioButton.Checked = false;
            earlyBirdRadioButton.Checked = false;
            nightlifeRadioButton.Checked = false;
            nightRateRadioButton.Checked = false;
            chargeLabel.Text = "$0.00";
            chargeLabel.ForeColor = Color.Red;
            chiParkingErrorProvider.SetError(parkingOptionsGroupBox, "");
            chiParkingErrorProvider.SetError(hoursNumericUpDown, "");
            hoursNumericUpDown.Focus();
        }
    }
}
