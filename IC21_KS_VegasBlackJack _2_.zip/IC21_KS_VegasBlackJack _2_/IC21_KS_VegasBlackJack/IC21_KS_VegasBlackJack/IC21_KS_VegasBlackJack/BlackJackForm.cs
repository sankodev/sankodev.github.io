﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC21_KS_VegasBlackJack
{
    public partial class BlackJackForm : Form
    {

        int wins = 0, draws = 0, losses = 0;
        int playerCardsShown = 0, dealerCardsShown = 0;

        //player
        PlayingCard playerCard1;
        PlayingCard playerCard2;
        PlayingCard playerCard3;
        PlayingCard playerCard4;
        PlayingCard playerCard5;

        //dealer
        PlayingCard dealerCard1;
        PlayingCard dealerCard2;
        PlayingCard dealerCard3;
        PlayingCard dealerCard4;
        PlayingCard dealerCard5;


        Random numberGenerator = new Random();
        int playerPoints = 0, dealerPoints = 0;

        List<PlayingCard> deckList = new List<PlayingCard>();

        int cardsRemaining = 52;

        public BlackJackForm()
        {
            InitializeComponent();
        }

        private void lossesLabel_Click(object sender, EventArgs e)
        {

        }

        private void BlackJackForm_Load(object sender, EventArgs e)
        {
            //hearts
            deckList.Add(new PlayingCard("Ace", "Hearts", Properties.Resources.ace_of_hearts, 11));
            deckList.Add(new PlayingCard("2", "Hearts", Properties.Resources._2_of_hearts, 2));
            deckList.Add(new PlayingCard("3", "Hearts", Properties.Resources._3_of_hearts, 3));
            deckList.Add(new PlayingCard("4", "Hearts", Properties.Resources._4_of_hearts, 4));
            deckList.Add(new PlayingCard("5", "Hearts", Properties.Resources._5_of_hearts, 5));
            deckList.Add(new PlayingCard("6", "Hearts", Properties.Resources._6_of_hearts, 6));
            deckList.Add(new PlayingCard("7", "Hearts", Properties.Resources._7_of_hearts, 7));
            deckList.Add(new PlayingCard("8", "Hearts", Properties.Resources._8_of_hearts, 8));
            deckList.Add(new PlayingCard("9", "Hearts", Properties.Resources._9_of_hearts, 9));
            deckList.Add(new PlayingCard("10", "Hearts", Properties.Resources._10_of_hearts, 10));
            deckList.Add(new PlayingCard("Jack", "Hearts", Properties.Resources.jack_of_hearts, 10));
            deckList.Add(new PlayingCard("Queen", "Hearts", Properties.Resources.queen_of_hearts, 10));
            deckList.Add(new PlayingCard("King", "Hearts", Properties.Resources.king_of_hearts, 10));

            //clubs
            deckList.Add(new PlayingCard("Ace", "Clubs", Properties.Resources.ace_of_clubs, 11));
            deckList.Add(new PlayingCard("2", "Clubs", Properties.Resources._2_of_clubs, 2));
            deckList.Add(new PlayingCard("3", "Clubs", Properties.Resources._3_of_clubs, 3));
            deckList.Add(new PlayingCard("4", "Clubs", Properties.Resources._4_of_clubs, 4));
            deckList.Add(new PlayingCard("5", "Clubs", Properties.Resources._5_of_clubs, 5));
            deckList.Add(new PlayingCard("6", "Clubs", Properties.Resources._6_of_clubs, 6));
            deckList.Add(new PlayingCard("7", "Clubs", Properties.Resources._7_of_clubs, 7));
            deckList.Add(new PlayingCard("8", "Clubs", Properties.Resources._8_of_clubs, 8));
            deckList.Add(new PlayingCard("9", "Clubs", Properties.Resources._9_of_clubs, 9));
            deckList.Add(new PlayingCard("10", "Clubs", Properties.Resources._10_of_clubs, 10));
            deckList.Add(new PlayingCard("Jack", "Clubs", Properties.Resources.jack_of_clubs, 10));
            deckList.Add(new PlayingCard("Queen", "Clubs", Properties.Resources.queen_of_clubs, 10));
            deckList.Add(new PlayingCard("King", "Clubs", Properties.Resources.king_of_clubs, 10));

            //diamonds
            deckList.Add(new PlayingCard("Ace", "Diamonds", Properties.Resources.ace_of_diamonds, 11));
            deckList.Add(new PlayingCard("2", "Diamonds", Properties.Resources._2_of_diamonds, 2));
            deckList.Add(new PlayingCard("3", "Diamonds", Properties.Resources._3_of_diamonds, 3));
            deckList.Add(new PlayingCard("4", "Diamonds", Properties.Resources._4_of_diamonds, 4));
            deckList.Add(new PlayingCard("5", "Diamonds", Properties.Resources._5_of_diamonds, 5));
            deckList.Add(new PlayingCard("6", "Diamonds", Properties.Resources._6_of_diamonds, 6));
            deckList.Add(new PlayingCard("7", "Diamonds", Properties.Resources._7_of_diamonds, 7));
            deckList.Add(new PlayingCard("8", "Diamonds", Properties.Resources._8_of_diamonds, 8));
            deckList.Add(new PlayingCard("9", "Diamonds", Properties.Resources._9_of_diamonds, 9));
            deckList.Add(new PlayingCard("10", "Diamonds", Properties.Resources._10_of_diamonds, 10));
            deckList.Add(new PlayingCard("Jack", "Diamonds", Properties.Resources.jack_of_diamonds, 10));
            deckList.Add(new PlayingCard("Queen", "Diamonds", Properties.Resources.queen_of_diamonds, 10));
            deckList.Add(new PlayingCard("King", "Diamonds", Properties.Resources.king_of_diamonds, 10));

            //spades
            deckList.Add(new PlayingCard("Ace", "Spades", Properties.Resources.ace_of_spades, 11));
            deckList.Add(new PlayingCard("2", "Spades", Properties.Resources._2_of_spades, 2));
            deckList.Add(new PlayingCard("3", "Spades", Properties.Resources._3_of_spades, 3));
            deckList.Add(new PlayingCard("4", "Spades", Properties.Resources._4_of_spades, 4));
            deckList.Add(new PlayingCard("5", "Spades", Properties.Resources._5_of_spades, 5));
            deckList.Add(new PlayingCard("6", "Spades", Properties.Resources._6_of_spades, 6));
            deckList.Add(new PlayingCard("7", "Spades", Properties.Resources._7_of_spades, 7));
            deckList.Add(new PlayingCard("8", "Spades", Properties.Resources._8_of_spades, 8));
            deckList.Add(new PlayingCard("9", "Spades", Properties.Resources._9_of_spades, 9));
            deckList.Add(new PlayingCard("10", "Spades", Properties.Resources._10_of_spades, 10));
            deckList.Add(new PlayingCard("Jack", "Spades", Properties.Resources.jack_of_spades, 10));
            deckList.Add(new PlayingCard("Queen", "Spades", Properties.Resources.queen_of_spades, 10));
            deckList.Add(new PlayingCard("King", "Spades", Properties.Resources.king_of_spades, 10));

            deckCountLabel.Text = cardsRemaining.ToString();
            hitButton.Hide();
            dealtCardListBox.Hide();
            showHideButton.Show();
            button3.Hide();

            deackPictureBox.Image = Properties.Resources.blank_red;
            playerCard5PictureBox.Hide();
            playerCard4PictureBox.Hide();
            playerCard3PictureBox.Hide();
            playerCard2PictureBox.Hide();
            playerCard1PictureBox.Hide();

            dealerCard5PictureBox.Hide();
            dealerCard4PictureBox.Hide();
            dealerCard3PictureBox.Hide();
            dealerCard2PictureBox.Hide();
            dealerCard1PictureBox.Hide();


        }

        private void hitButton_Click(object sender, EventArgs e)
        {
            

            switch (playerCardsShown)
            {
                case 2:
                playerCard3PictureBox.Show();
                playerCard3PictureBox.Image = playerCard3.CardFace;
                playerPoints += playerCard3.Points;
                dealtCardListBox.Items.Add(playerCard3.ToString());
                deckList.Remove(playerCard3);
                break;

                case 3:
                playerCard4PictureBox.Show();
                playerCard4PictureBox.Image = playerCard4.CardFace;
                playerPoints += playerCard4.Points;
                dealtCardListBox.Items.Add(playerCard4.ToString());
                deckList.Remove(playerCard4);
                break;

                case 4:
                playerCard5PictureBox.Show();
                playerCard5PictureBox.Image = playerCard5.CardFace;
                playerPoints += playerCard5.Points;
                deckList.Remove(playerCard5);
                break;

                //default:
                //    break;
            }

            playerPointsLabel.Text = playerPoints.ToString();

            if (playerPoints > 21)
            {
                MessageBox.Show("Bust!", "Sorry Cowboy...", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Stop);
                losses++;
                hitButton.Hide();
                dealButton.Show();
                standButton.Enabled = false;
                playerPointsLabel.Text = "";
                dealerPointsLabel.Text = "";
                playerCard3PictureBox.Hide();
                playerCard4PictureBox.Hide();
                playerCard5PictureBox.Hide();
            }
            //else
            //{
            //    return;
            //}

        }

        private void dealButton_Click(object sender, EventArgs e)
        {
            dealButton.Hide();
            hitButton.Show();

            dealerCard1PictureBox.Show();
            dealerCard2PictureBox.Show();

            playerCard1PictureBox.Show();
            playerCard2PictureBox.Show();

            playerCardsShown = 2;

            Random numberGenerator = new Random();

            //player
            //PlayingCard playerCard1 = deckList[numberGenerator.Next(0, deckList.Count)];
            //PlayingCard playerCard2 = deckList[numberGenerator.Next(0, deckList.Count)];
            //PlayingCard playerCard3 = deckList[numberGenerator.Next(0, deckList.Count)];
            //PlayingCard playerCard4 = deckList[numberGenerator.Next(0, deckList.Count)];
            //PlayingCard playerCard5 = deckList[numberGenerator.Next(0, deckList.Count)];

            playerCard1 = deckList[numberGenerator.Next(0, deckList.Count)];
            playerCard2 = deckList[numberGenerator.Next(0, deckList.Count)];
            playerCard3 = deckList[numberGenerator.Next(0, deckList.Count)];
            playerCard4 = deckList[numberGenerator.Next(0, deckList.Count)];
            playerCard5 = deckList[numberGenerator.Next(0, deckList.Count)];


            //dealer
            //PlayingCard dealerCard1 = deckList[numberGenerator.Next(0, deckList.Count)];
            //PlayingCard dealerCard2 = deckList[numberGenerator.Next(0, deckList.Count)];
            //PlayingCard dealerCard3 = deckList[numberGenerator.Next(0, deckList.Count)];
            //PlayingCard dealerCard4 = deckList[numberGenerator.Next(0, deckList.Count)];
            //PlayingCard dealerCard5 = deckList[numberGenerator.Next(0, deckList.Count)];

            dealerCard1 = deckList[numberGenerator.Next(0, deckList.Count)];
            dealerCard2 = deckList[numberGenerator.Next(0, deckList.Count)];
            dealerCard3 = deckList[numberGenerator.Next(0, deckList.Count)];
            dealerCard4 = deckList[numberGenerator.Next(0, deckList.Count)];
            dealerCard5 = deckList[numberGenerator.Next(0, deckList.Count)];

            //display in player's card pictureBox
            playerCard1PictureBox.Image = playerCard1.CardFace;
            playerCard2PictureBox.Image = playerCard2.CardFace;
            //playerCard3PictureBox.Image = card3.CardFace;
            //playerCard4PictureBox.Image = card4.CardFace;
            //playerCard5PictureBox.Image = card5.CardFace;
            playerCard3PictureBox.Hide();
            playerCard4PictureBox.Hide();
            playerCard5PictureBox.Hide();

            //dealer cards picturebox
            dealerCard1PictureBox.Image = Properties.Resources.blank_red;
            dealerCard2PictureBox.Image = dealerCard2.CardFace;
            dealerCard3PictureBox.Hide();
            dealerCard4PictureBox.Hide();
            dealerCard5PictureBox.Hide();

            


            //display in listBox
            
            dealtCardListBox.Items.Add(playerCard1.ToString());
            dealtCardListBox.Items.Add(playerCard2.ToString());
            //dealtCardListBox.Items.Add(card3.ToString());
            //dealtCardListBox.Items.Add(card4.ToString());
            dealtCardListBox.Items.Add(dealerCard1.ToString());
            dealtCardListBox.Items.Add(dealerCard2.ToString());


            playerPoints += playerCard1.Points;
            deckList.Remove(playerCard1);
            playerPoints += playerCard2.Points;
            deckList.Remove(playerCard2);

            playerPointsLabel.Text = playerPoints.ToString();

            //dealerPoints += dealerCard1.Points;
            deckList.Remove(dealerCard1);
            dealerPoints += dealerCard2.Points;
            deckList.Remove(dealerCard2);

            dealerPointsLabel.Text = dealerPoints.ToString();


        }

        private void button3_Click(object sender, EventArgs e)
        {
            showHideButton.Show();
            button3.Hide();
            dealtCardListBox.Hide();
        }

        private void showHideButton_Click(object sender, EventArgs e)
        {
            showHideButton.Hide();
            button3.Show();
            dealtCardListBox.Show();
        }
    }
}
