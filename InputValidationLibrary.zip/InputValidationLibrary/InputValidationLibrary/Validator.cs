﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InputValidationLibrary
{
    public class Validator
    {
        /// <summary>
        /// Validates a textbox within a range between anyMinimum and anyMaximum. Shows an error label if input is invalid
        /// </summary>
        /// <param name="anyValue">The value stored from the text box</param>
        /// <param name="anyTextBox">The text box to be validated</param>
        /// <param name="anyMinimum">The minimum value allowed</param>
        /// <param name="anyMaximum">The maximum value allowed</param>
        /// <param name="anyErrorLabel">The error label shown if the input is invalid</param>
        /// <returns>True if input is valid, False otherwise</returns>
        public static bool IsInputValid(ref double anyValue, TextBox anyTextBox, double anyMinimum, double anyMaximum, Label anyErrorLabel)
        {
            if (!double.TryParse(anyTextBox.Text, out anyValue) || anyValue < anyMinimum || anyValue > anyMaximum)
            {
                anyErrorLabel.Show();
                anyTextBox.Focus();
                anyTextBox.SelectAll();
                return false;
            }
            anyErrorLabel.Hide();
            return true;
        }

        /// <summary>
        /// Validates a textbox within a range between anyMinimum and anyMaximum. Shows an error label if input is invalid
        /// </summary>
        /// <param name="anyValue">The value stored from the text box</param>
        /// <param name="anyTextBox">The text box to be validated</param>
        /// <param name="anyMinimum">The minimum value allowed</param>
        /// <param name="anyErrorLabel">The error label shown if the input is invalid</param>
        /// <returns>True if input is valid, False otherwise</returns>
        public static bool IsInputValidLowerBound(ref double anyValue, TextBox anyTextBox, double anyMinimum, Label anyErrorLabel)
        {
            return IsInputValid(ref anyValue, anyTextBox, anyMinimum, double.MaxValue, anyErrorLabel);
        }

        /// <summary>
        /// Validates a textbox within a range between anyMinimum and anyMaximum. Shows an error label if input is invalid
        /// </summary>
        /// <param name="anyValue">The value stored from the text box</param>
        /// <param name="anyTextBox">The text box to be validated</param>
        /// <param name="anyMaximum">The maximum value allowed</param>
        /// <param name="anyErrorLabel">The error label shown if the input is invalid</param>
        /// <returns>True if input is valid, False otherwise</returns>
        public static bool IsInputValidUpperBound(ref double anyValue, TextBox anyTextBox, double anyMaximum, Label anyErrorLabel)
        {
            return IsInputValid(ref anyValue, anyTextBox, double.MinValue, anyMaximum, anyErrorLabel);
        }

        /// <summary>
        /// Validates a textbox within a range between anyMinimum and anyMaximum. Shows an error provider if input is invalid
        /// </summary>
        /// <param name="anyValue">The value stored from the text box</param>
        /// <param name="anyTextBox">The text box to be validated</param>
        /// <param name="anyMinimum">The minimum value allowed</param>
        /// <param name="anyMaximum">The maximum value allowed</param>
        /// <param name="anyErrorProvider">The error provider shown if the input is invalid</param>
        /// <param name="anyErrorMessage">The error message shown if the input is invalid</param>
        /// <returns>True if input is valid, False otherwise</returns>
        public static bool IsInputValid(ref double anyValue, TextBox anyTextBox, double anyMinimum, double anyMaximum, ErrorProvider anyErrorProvider, string anyErrorMessage)
        {
            if (!double.TryParse(anyTextBox.Text, out anyValue) || anyValue < anyMinimum || anyValue > anyMaximum)
            {
                anyErrorProvider.SetError(anyTextBox, anyErrorMessage);
                anyTextBox.Focus();
                anyTextBox.SelectAll();
                return false;
            }
            anyErrorProvider.SetError(anyTextBox, "");
            return true;
        }

        /// <summary>
        /// Validates a textbox within a range between anyMinimum and anyMaximum. Shows an error provider if input is invalid
        /// </summary>
        /// <param name="anyValue">The value stored from the text box</param>
        /// <param name="anyTextBox">The text box to be validated</param>
        /// <param name="anyMinimum">The minimum value allowed</param>
        /// <param name="anyErrorProvider">The error provider shown if the input is invalid</param>
        /// <param name="anyErrorMessage">The error message shown if the input is invalid</param>
        /// <returns>True if input is valid, False otherwise</returns>
        public static bool IsInputValidLowerBound(ref double anyValue, TextBox anyTextBox, double anyMinimum, ErrorProvider anyErrorProvider, string anyErrorMessage)
        {
            return IsInputValid(ref anyValue, anyTextBox, anyMinimum, double.MaxValue, anyErrorProvider, anyErrorMessage);
        }

        /// <summary>
        /// Validates a textbox within a range between anyMinimum and anyMaximum. Shows an error provider if input is invalid
        /// </summary>
        /// <param name="anyValue">The value stored from the text box</param>
        /// <param name="anyTextBox">The text box to be validated</param>
        /// <param name="anyMaximum">The maximum value allowed</param>
        /// <param name="anyErrorProvider">The error provider shown if the input is invalid</param>
        /// <param name="anyErrorMessage">The error message shown if the input is invalid</param>
        /// <returns>True if input is valid, False otherwise</returns>
        public static bool IsInputValidUpperBound(ref double anyValue, TextBox anyTextBox, double anyMaximum, ErrorProvider anyErrorProvider, string anyErrorMessage)
        {
            return IsInputValid(ref anyValue, anyTextBox, double.MinValue, anyMaximum, anyErrorProvider, anyErrorMessage);
        }
    }
}
