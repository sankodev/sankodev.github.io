﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IC22_KS_BankAcc
{
    public class SavingsAccount : BankAccount
    {
        private double _interestRate;
        private string _customerId;
        private decimal _balance;
        private string _accountNumber;
        private string _name;
        private string _creditScore;

        public SavingsAccount(string accountNumber, string customerId, decimal balance, string name, string creditScore, double interestRate)
        {
            //throw new System.NotImplementedException();

            _accountNumber = accountNumber;
            _customerId = customerId;
            _balance = balance;
            _name = name;
            _creditScore = creditScore;
            _interestRate = interestRate;
        }

        public double InterestRate
        {
            get
            {
                return _interestRate;
            }
            //set
            //{
            //}
        }

        public string AccountNumber
        {
            get
            {
                return _accountNumber;
            }
            set
            {
                _accountNumber = value;
            }
        }

        public string CustomerId
        {
            get
            {
                return _customerId;
            }
            set
            {
                _customerId = value;
            }
        }

        public decimal Balance
        {
            get
            {
                return _balance;
            }
            set
            {
                _balance = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }
        }

        public string CreditScore
        {
            get
            {
                return _creditScore;
            }
        }


        public override string ToString()
        {
            string output = _accountNumber + "," + _customerId + "," + _balance + "," + _name + "," + _creditScore + "," + _interestRate;

            return output;
        }

        public override bool Deposit(decimal transactionAmount)
        {
            if (transactionAmount <= 0m)
            {
                return false;
            }
            else
            {
                
                _balance += transactionAmount;
                return true;
            }
        }

        public override bool Withdraw(decimal transactionAmount)
        {
            if (transactionAmount <= 0m)
            {
                return false;
            }
            else
            {
                _balance -= transactionAmount;
                return true;
            }
        }
    }
}
