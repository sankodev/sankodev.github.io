﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IC22_KS_BankAcc
{
    public class CheckingAccount : BankAccount
    {
        private bool _overdraftProtection;
        private string _customerId;
        private decimal _balance;
        private string _accountNumber;
        private string _name;
        private string _creditScore;

        public CheckingAccount(string accountNumber, string customerId, decimal balance, string name, string creditScore, bool overdraftProtection)
        {
            //throw new System.NotImplementedException();
            _accountNumber = accountNumber;
            _customerId = customerId;
            _balance = balance;
            _name = name;
            _creditScore = creditScore;
            _overdraftProtection = overdraftProtection;
        }
    
        public bool OverdraftProtection
        {
            get
            {
                return _overdraftProtection;
                //throw new System.NotImplementedException();
            }
            //set
            //{

            //}
        }

        public string AccountNumber
        {
            get
            {
                return _accountNumber;
            }
            set
            {
                _accountNumber = value;
            }
        }

        public string CustomerId
        {
            get
            {
                return _customerId;
            }
            set
            {
                _customerId = value;
            }
        }

        public decimal Balance
        {
            get
            {
                return _balance;
            }
            set
            {
                _balance = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }
        }

        public string CreditScore
        {
            get
            {
                return _creditScore;
            }
        }

        public override string ToString()
        {
            string output = _accountNumber + "," + _customerId + "," + _balance + "," + _name + "," + _creditScore + "," + _overdraftProtection;

            return output;
        }

        public override bool Deposit(decimal transactionAmount)
        {
            if (transactionAmount <= 0m)
            {
                return false;
            }
            else
            {
                _balance += transactionAmount;
                return true;
            }
        }

        public override bool Withdraw(decimal transactionAmount)
        {
            if (transactionAmount <= 0m)
            {
                return false;
            }
            else
            {
                _balance -= transactionAmount;
                return true;
            }
        }
    }
}
