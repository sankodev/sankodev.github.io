﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InputValidation
{
    public class Validator
    {
        /// <summary>
        /// Validates a text box with numeric input.  Shows error label
        /// if input is invalid.
        /// </summary>
        /// <param name="anyTextBox">A text box with numeric input</param>
        /// <param name="anyValue">The value to be stored if input is valid</param>
        /// <param name="anyMin">The minimum value allowed</param>
        /// <param name="anyMax">The maximum value allowed</param>
        /// <param name="anyErrorLabel">The error label shown if input is invalid</param>
        /// <returns>True, if the input is valid, false otherwise</returns>
        /// 



        //double
        public static bool IsInputValid(TextBox anyTextBox, ref double anyValue, double anyMin, double anyMax, Label anyErrorLabel)
        {
            if (!double.TryParse(anyTextBox.Text, out anyValue) || anyValue < anyMin || anyValue > anyMax)
            {
                anyErrorLabel.Show();
                anyTextBox.Focus();
                anyTextBox.SelectAll();
                return false;
            }
            anyErrorLabel.Hide();
            return true;
        }

        public bool IsInputValidMinimum(TextBox anyTextBox, ref double anyValue, double anyMin, Label anyErrorLabel)
        {
            return IsInputValid(anyTextBox, ref anyValue, anyMin, double.MaxValue, anyErrorLabel);
        }

        public bool IsInputValidMaximum(TextBox anyTextBox, ref double anyValue, double anyMax, Label anyErrorLabel)
        {
            return IsInputValid(anyTextBox, ref anyValue, anyMax, double.MinValue, anyErrorLabel);
        }

        //public bool IsInputValidMaximum(TextBox anyTextbox, ref double anyValue, double anyMax, Label anyErrorLabel)
        //{
        //    return IsInputValid(anyTextBox, ref anyValue, double.MinValue, anyMax, anyErrorLabel);
        //}


        public static bool IsInputValid(TextBox anyTextBox, ref double anyValue, double anyMin, double anyMax, ErrorProvider anyErrorProvider, string anyErrorMessage)
        {
            if (!double.TryParse(anyTextBox.Text, out anyValue) || anyValue < anyMin || anyValue > anyMax)
            {
                anyErrorLabel.Show();
                anyTextBox.Focus();
                anyTextBox.SelectAll();
                return false;
            }
            anyErrorLabel.Hide();
            return true;
        }











        //string
        public static bool IsInputValid(TextBox anyTextBox, ref string anyValue, string anyMin, string anyMax, Label anyErrorLabel)
        {
            if (!string.IsNullOrWhiteSpace(anyTextBox.Text))
            {
                anyErrorLabel.Show();
                anyTextBox.Focus();
                anyTextBox.SelectAll();
                return false;
            }
            anyErrorLabel.Hide();
            return true;
        }






        //decimal
        public static bool IsInputValid(TextBox anyTextBox, ref decimal anyValue, decimal anyMin, decimal anyMax, Label anyErrorLabel)
        {
            if (!decimal.TryParse(anyTextBox.Text, out anyValue) || anyValue < anyMin || anyValue > anyMax)
            {
                anyErrorLabel.Show();
                anyTextBox.Focus();
                anyTextBox.SelectAll();
                return false;
            }
            anyErrorLabel.Hide();
            return true;
        }







        //int
        


    }
}
