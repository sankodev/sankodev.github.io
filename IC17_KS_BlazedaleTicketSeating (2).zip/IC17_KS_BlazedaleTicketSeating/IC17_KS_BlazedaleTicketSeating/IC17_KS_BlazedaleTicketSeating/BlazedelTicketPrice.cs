﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC17_KS_BlazedaleTicketSeating
{
    public partial class BlazedelTicketPrice : Form
    {
        public BlazedelTicketPrice()
        {
            InitializeComponent();
        }

        decimal[] seatPricesArray = { 114.10m, 98.75m, 82.85m, 69.50m };
        int totalSeatsOrdered = 0;
        decimal totalAmountPaid = 0m;

        private int CalculateTotalSeatsOrdered(int quant)
        {
            int resultSeats = quant;
            return resultSeats;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            quantComboBox.SelectedIndex = 0;
            seatTypeComboBox.SelectedIndex = 0;
            subtotalLabel.Text = "";

        }

        private void BlazedelTicketPrice_Load(object sender, EventArgs e)
        {
            quantErrorLabel.Hide();
            seatTypeErrorLabel.Hide();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            decimal subtotal, seatPrice;
            int quant;

            if (quantComboBox.SelectedIndex  < 0)
            {
                quantErrorLabel.Show();
                quantComboBox.Focus();
                return;
            }
            if (seatTypeComboBox.SelectedIndex < 0)
            {
                seatTypeErrorLabel.Show();
                seatTypeComboBox.Focus();
                return;
            }

            quant = Convert.ToInt32(quantComboBox.Text);

            seatPrice = seatPricesArray[seatTypeComboBox.SelectedIndex];

            // multi & display

            subtotal = quant* seatPrice;
            subtotalLabel.Text = subtotal.ToString("C");

            totalSeatsOrdered = totalSeatsOrdered + quant;
            totalAmountPaid = subtotal + totalAmountPaid;


            //tot seats ordered & tot amount paid
            totalAmountPaidLabel.Text = totalAmountPaid.ToString("C");
            totalSeatsOrderedLabel.Text = totalSeatsOrdered.ToString();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
