﻿namespace IC17_KS_BlazedaleTicketSeating
{
    partial class BlazedelTicketPrice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.quantComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.seatTypeErrorLabel = new System.Windows.Forms.Label();
            this.quantErrorLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.subtotalLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.seatTypeComboBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.totalSeatsOrderedLabel = new System.Windows.Forms.Label();
            this.totalAmountPaidLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // quantComboBox
            // 
            this.quantComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.quantComboBox.FormattingEnabled = true;
            this.quantComboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.quantComboBox.Location = new System.Drawing.Point(82, 59);
            this.quantComboBox.Name = "quantComboBox";
            this.quantComboBox.Size = new System.Drawing.Size(121, 21);
            this.quantComboBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Quantity:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.seatTypeErrorLabel);
            this.groupBox1.Controls.Add(this.quantErrorLabel);
            this.groupBox1.Controls.Add(this.calculateButton);
            this.groupBox1.Controls.Add(this.subtotalLabel);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.seatTypeComboBox);
            this.groupBox1.Controls.Add(this.quantComboBox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(32, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(551, 251);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tickets:";
            // 
            // seatTypeErrorLabel
            // 
            this.seatTypeErrorLabel.AutoSize = true;
            this.seatTypeErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.seatTypeErrorLabel.Location = new System.Drawing.Point(389, 92);
            this.seatTypeErrorLabel.Name = "seatTypeErrorLabel";
            this.seatTypeErrorLabel.Size = new System.Drawing.Size(92, 13);
            this.seatTypeErrorLabel.TabIndex = 8;
            this.seatTypeErrorLabel.Text = "Select a seat type";
            // 
            // quantErrorLabel
            // 
            this.quantErrorLabel.AutoSize = true;
            this.quantErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.quantErrorLabel.Location = new System.Drawing.Point(94, 92);
            this.quantErrorLabel.Name = "quantErrorLabel";
            this.quantErrorLabel.Size = new System.Drawing.Size(109, 13);
            this.quantErrorLabel.TabIndex = 7;
            this.quantErrorLabel.Text = "Select a seat quantity";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(243, 201);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 2;
            this.calculateButton.Text = "&Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // subtotalLabel
            // 
            this.subtotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.subtotalLabel.Location = new System.Drawing.Point(195, 122);
            this.subtotalLabel.Name = "subtotalLabel";
            this.subtotalLabel.Size = new System.Drawing.Size(189, 51);
            this.subtotalLabel.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(128, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Subtotal:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(319, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Seat Type:";
            // 
            // seatTypeComboBox
            // 
            this.seatTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.seatTypeComboBox.FormattingEnabled = true;
            this.seatTypeComboBox.Items.AddRange(new object[] {
            "Floor Seat: $114.10",
            "Riser Seat: $98.75",
            "Loge Seat: $82.85",
            "Upper Seat: $69.50"});
            this.seatTypeComboBox.Location = new System.Drawing.Point(382, 59);
            this.seatTypeComboBox.Name = "seatTypeComboBox";
            this.seatTypeComboBox.Size = new System.Drawing.Size(121, 21);
            this.seatTypeComboBox.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(452, 317);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Total Seats Ordered:";
            // 
            // totalSeatsOrderedLabel
            // 
            this.totalSeatsOrderedLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalSeatsOrderedLabel.Location = new System.Drawing.Point(450, 349);
            this.totalSeatsOrderedLabel.Name = "totalSeatsOrderedLabel";
            this.totalSeatsOrderedLabel.Size = new System.Drawing.Size(107, 35);
            this.totalSeatsOrderedLabel.TabIndex = 4;
            // 
            // totalAmountPaidLabel
            // 
            this.totalAmountPaidLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalAmountPaidLabel.Location = new System.Drawing.Point(450, 437);
            this.totalAmountPaidLabel.Name = "totalAmountPaidLabel";
            this.totalAmountPaidLabel.Size = new System.Drawing.Size(107, 35);
            this.totalAmountPaidLabel.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(460, 408);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Total Amount Paid:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::IC17_KS_BlazedaleTicketSeating.Properties.Resources.BlazedellCenter;
            this.pictureBox1.Location = new System.Drawing.Point(57, 332);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(199, 158);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(402, 496);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 1;
            this.clearButton.Text = "C&lear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(526, 496);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // BlazedelTicketPrice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(638, 554);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.totalAmountPaidLabel);
            this.Controls.Add(this.totalSeatsOrderedLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox1);
            this.Name = "BlazedelTicketPrice";
            this.Text = "Blazedel Ticket Prices";
            this.Load += new System.EventHandler(this.BlazedelTicketPrice_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox quantComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label subtotalLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox seatTypeComboBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label totalSeatsOrderedLabel;
        private System.Windows.Forms.Label totalAmountPaidLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label seatTypeErrorLabel;
        private System.Windows.Forms.Label quantErrorLabel;
    }
}

